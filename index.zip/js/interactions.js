import Character from './character.js';

export default {
  init: function () {
  },

  checkForInteraction: function () {
    let characterPosition = Character.getCharacterPosition();
  },

};